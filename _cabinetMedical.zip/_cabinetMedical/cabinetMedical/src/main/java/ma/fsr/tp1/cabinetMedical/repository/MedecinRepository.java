package ma.fsr.tp1.cabinetMedical.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ma.fsr.tp1.cabinetMedical.model.Medecin;

public interface MedecinRepository extends JpaRepository<Medecin, Long> {
}
