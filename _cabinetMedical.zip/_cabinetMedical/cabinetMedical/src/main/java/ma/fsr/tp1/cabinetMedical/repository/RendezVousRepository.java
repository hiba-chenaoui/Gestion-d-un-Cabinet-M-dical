package ma.fsr.tp1.cabinetMedical.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ma.fsr.tp1.cabinetMedical.model.RendezVous;

public interface RendezVousRepository extends JpaRepository<RendezVous, Long> {
}
