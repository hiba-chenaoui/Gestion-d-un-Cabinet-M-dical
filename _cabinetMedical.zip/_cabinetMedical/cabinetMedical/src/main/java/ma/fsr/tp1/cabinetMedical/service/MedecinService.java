package ma.fsr.tp1.cabinetMedical.service;

import org.springframework.stereotype.Service;
import ma.fsr.tp1.cabinetMedical.model.Medecin;
import ma.fsr.tp1.cabinetMedical.repository.MedecinRepository;
import java.util.List;

@Service
public class MedecinService {

    private final MedecinRepository medecinRepository;

    public MedecinService(MedecinRepository medecinRepository) {
        this.medecinRepository = medecinRepository;
    }

    public Medecin creerMedecin(Medecin medecin) {
        return medecinRepository.save(medecin);
    }

    public List<Medecin> listerMedecins() {
        return medecinRepository.findAll();
    }
}
