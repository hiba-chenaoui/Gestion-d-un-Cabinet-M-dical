package ma.fsr.tp1.cabinetMedical.service;

import org.springframework.stereotype.Service;
import ma.fsr.tp1.cabinetMedical.model.*;
import ma.fsr.tp1.cabinetMedical.repository.*;
import java.time.LocalDate;
import java.util.List;

@Service
public class RendezVousService {

    private final RendezVousRepository rendezVousRepository;
    private final PatientRepository patientRepository;
    private final MedecinRepository medecinRepository;

    public RendezVousService(
            RendezVousRepository rendezVousRepository,
            PatientRepository patientRepository,
            MedecinRepository medecinRepository) {

        this.rendezVousRepository = rendezVousRepository;
        this.patientRepository = patientRepository;
        this.medecinRepository = medecinRepository;
    }

    public RendezVous creerRendezVous(Long patientId, Long medecinId, LocalDate date) {
        Patient patient = patientRepository.findById(patientId).orElseThrow();
        Medecin medecin = medecinRepository.findById(medecinId).orElseThrow();

        RendezVous rdv = new RendezVous();
        rdv.setDateRdv(date);
        rdv.setStatut("PLANIFIE");
        rdv.setPatient(patient);
        rdv.setMedecin(medecin);

        return rendezVousRepository.save(rdv);
    }

    public List<RendezVous> listerRendezVous() {
        return rendezVousRepository.findAll();
    }
}
