package ma.fsr.tp1.cabinetMedical.service;

import org.springframework.stereotype.Service;
import ma.fsr.tp1.cabinetMedical.model.Patient;
import ma.fsr.tp1.cabinetMedical.repository.PatientRepository;
import java.util.List;

@Service
public class PatientService {

    private final PatientRepository patientRepository;

    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    // Créer un patient
    public Patient creerPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    // Lister tous les patients
    public List<Patient> listerPatients() {
        return patientRepository.findAll();
    }
}
