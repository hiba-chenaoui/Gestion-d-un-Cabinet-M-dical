package ma.fsr.tp1.cabinetMedical.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class RendezVous {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate dateRdv;
    private String statut;

    @ManyToOne
    private Patient patient;

    @ManyToOne
    private Medecin medecin;

    public RendezVous() {}

    public Long getId() { return id; }

    public LocalDate getDateRdv() { return dateRdv; }
    public void setDateRdv(LocalDate dateRdv) { this.dateRdv = dateRdv; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }

    public Medecin getMedecin() { return medecin; }
    public void setMedecin(Medecin medecin) { this.medecin = medecin; }
}
