package ma.fsr.tp1.cabinetMedical.web;

import org.springframework.web.bind.annotation.*;
import ma.fsr.tp1.cabinetMedical.model.Patient;
import ma.fsr.tp1.cabinetMedical.service.PatientService;
import java.util.List;

@RestController
@RequestMapping("/patients")
public class PatientController {

    private final PatientService patientService;

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    // POST /patients → créer un patient
    @PostMapping
    public Patient creerPatient(@RequestBody Patient patient) {
        return patientService.creerPatient(patient);
    }

    // GET /patients → lister les patients
    @GetMapping
    public List<Patient> listerPatients() {
        return patientService.listerPatients();
    }
}
