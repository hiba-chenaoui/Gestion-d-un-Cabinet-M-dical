package ma.fsr.tp1.cabinetMedical.web;

import org.springframework.web.bind.annotation.*;
import ma.fsr.tp1.cabinetMedical.model.RendezVous;
import ma.fsr.tp1.cabinetMedical.service.RendezVousService;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/rendezvous")
public class RendezVousController {

    private final RendezVousService rendezVousService;

    public RendezVousController(RendezVousService rendezVousService) {
        this.rendezVousService = rendezVousService;
    }

    @PostMapping
    public RendezVous creerRendezVous(
            @RequestParam Long patientId,
            @RequestParam Long medecinId,
            @RequestParam String date) {

        return rendezVousService.creerRendezVous(
                patientId,
                medecinId,
                LocalDate.parse(date)
        );
    }

    @GetMapping
    public List<RendezVous> listerRendezVous() {
        return rendezVousService.listerRendezVous();
    }
}
