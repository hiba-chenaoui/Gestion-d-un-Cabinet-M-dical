package ma.fsr.tp1.cabinetMedical.web;

import org.springframework.web.bind.annotation.*;
import ma.fsr.tp1.cabinetMedical.model.Medecin;
import ma.fsr.tp1.cabinetMedical.service.MedecinService;
import java.util.List;

@RestController
@RequestMapping("/medecins")
public class MedecinController {

    private final MedecinService medecinService;

    public MedecinController(MedecinService medecinService) {
        this.medecinService = medecinService;
    }

    @PostMapping
    public Medecin creerMedecin(@RequestBody Medecin medecin) {
        return medecinService.creerMedecin(medecin);
    }

    @GetMapping
    public List<Medecin> listerMedecins() {
        return medecinService.listerMedecins();
    }
}
