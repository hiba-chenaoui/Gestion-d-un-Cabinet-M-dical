package ma.fsr.tp1.cabinetMedical.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ma.fsr.tp1.cabinetMedical.model.Patient;

public interface PatientRepository extends JpaRepository<Patient, Long> {
}
